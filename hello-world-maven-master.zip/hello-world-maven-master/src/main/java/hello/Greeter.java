package hello;

public class Greeter {
	public String sayHello() {
		return "Hi Atin Gupta! v10";
	}
}
